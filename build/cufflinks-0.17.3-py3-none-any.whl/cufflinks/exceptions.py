class CufflinksError(Exception):
		pass